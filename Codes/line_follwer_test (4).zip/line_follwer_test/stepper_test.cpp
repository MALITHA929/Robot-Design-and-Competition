#include "stepper_test.h"

// Create AccelStepper objects (using DRIVER mode)
AccelStepper stepperX(AccelStepper::DRIVER, X_STEP_PIN, X_DIR_PIN);
AccelStepper stepperY(AccelStepper::DRIVER, Y_STEP_PIN, Y_DIR_PIN);

void initMotors() {
  pinMode(ENABLE_PIN, OUTPUT);
  digitalWrite(ENABLE_PIN, LOW); // Enable all drivers

  // Configure X motor
  stepperX.setMaxSpeed(1000);      // steps/second
  stepperX.setAcceleration(50);   // steps/second^2
  stepperX.setSpeed(0);

  // Configure Y motor
  stepperY.setMaxSpeed(1000);
  stepperY.setAcceleration(50);
  stepperY.setSpeed(0);
}

void moveMotors(long stepsX, long stepsY) {
  stepperX.moveTo(stepsX);
  stepperY.moveTo(-stepsY);

  // Run both motors until finished
  while (stepperX.distanceToGo() != 0 || stepperY.distanceToGo() != 0) {
    stepperX.run();
    stepperY.run();
  }
}

 void setMotorSpeed(float speedX, float speedY) {
   stepperX.setSpeed(speedX);
   stepperY.setSpeed(speedY);
 }


void stopMotors() {
  stepperX.stop();
  stepperY.stop();
}
