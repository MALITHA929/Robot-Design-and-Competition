#include "stepper_test.h"
#include "ir_array_test.h"
#include <Arduino.h>
#include <Wire.h>
#include "Adafruit_VL53L0X.h"
#include "Adafruit_TCS34725.h"
#include <Servo.h>

Servo myServo;


// #define PCA_ADDR 0x70

// void selectPCA(uint8_t ch) {
//   Wire.beginTransmission(PCA_ADDR);
//   Wire.write(1 << ch);
//   Wire.endTransmission();
//   delay(2);
// }


//uint16_t distanceA, distanceB, distanceC;


// // Create sensor object
// Adafruit_TCS34725 tcs = Adafruit_TCS34725(
//     TCS34725_INTEGRATIONTIME_50MS, // how long to collect light
//     TCS34725_GAIN_4X                // gain for sensitivity
// );
// #define PCA_TCS1_CH 1


#define MUX_ADDR 0x70   // single TCA9548A
#define RED 35
#define BLUE 34
#define GREEN 36



// ====================== XSHUT PINS ======================
int xshutPins[3] = {48,49,50};

// ====================== VL53 Objects ====================
Adafruit_VL53L0X vl53[3];
byte vl53Addresses[3] = {0x30, 0x31, 0x32};

// ====================== TCS Objects =====================
Adafruit_TCS34725 tcs[1] = {
   Adafruit_TCS34725()
  // Adafruit_TCS34725(),
  // Adafruit_TCS34725()
};

// ====================== MUX select =======================
void tcaSelect(uint8_t ch) {
  Wire.beginTransmission(MUX_ADDR);
  Wire.write(1 << ch);
  Wire.endTransmission();
}




long i = 0;
long j = 0;

long distances[3];
  


void setup() {
//   // put your setup code here, to run once:


   initSensors();
   initMotors();
   setMotorSpeed(1, 1);

  Serial.begin(115200);

   //myServo.attach(2);


  // Wire.begin();

  // /////////////////// Colors //////////////////
  // pinMode(RED, OUTPUT);
  // pinMode(BLUE, OUTPUT);
  // pinMode(GREEN, OUTPUT);


  // // ---- Prepare XSHUT pins ----
  // for (int i = 0; i < 6; i++) {
  //   pinMode(xshutPins[i], OUTPUT);
  //   digitalWrite(xshutPins[i], LOW);
  // }
  // delay(50);

  // Serial.println("Initializing VL53L0X sensors...");

  // // ========== Initialize all VL53 sensors on Channel 0 ==========
  // tcaSelect(0);

  // for (int i = 0; i < 3; i++) {

  //   // enable only one sensor
  //   digitalWrite(xshutPins[i], HIGH);
  //   delay(20);

  //   if (!vl53[i].begin()) {
  //     Serial.print("VL53 INIT FAILED at sensor ");
  //     Serial.println(i);
  //     while (1);
  //   }

  //   // assign new I2C address
  //   vl53[i].setAddress(vl53Addresses[i]);

  //   Serial.print("VL53 Sensor ");
  //   Serial.print(i);
  //   Serial.print(" set to address 0x");
  //   Serial.println(vl53Addresses[i], HEX);
  // }

  // Serial.println("All VL53 sensors initialized!");

  // // ========== Initialize 3 TCS3472 sensors ==========
  // Serial.println("Initializing TCS3472 color sensors...");

  // for (int i = 0; i < 1; i++) {
  //   tcaSelect(i + 1); // color sensors on channels 1,2,3
  //   delay(50);

  //   if (!tcs[i].begin()) {
  //     Serial.print("TCS3472 FAILED at channel ");
  //     Serial.println(i + 1);
  //     while (1);
  //   }

  //   Serial.print("TCS3472 OK at channel ");
  //   Serial.println(i + 1);
  // }

  // Serial.println("All sensors initialized successfully!");

  
//   Wire.begin();
//   init_distance_Sensors();
//   delay(500);

//   if (tcs.begin()) {
//       Serial.println("TCS34725 detected!");
//   } else {
//       Serial.println("No TCS34725 found... check wiring!");
//       while (1);
//   }

  
    

 }

void loop() {


    // ================= DISTANCE SENSORS ====================
  // Serial.println("==== Distance Sensors ====");

  // tcaSelect(0); // all VL53L0X on channel 0

  // for (int i = 0; i < 3; i++) {
  //   VL53L0X_RangingMeasurementData_t measure;
  //   vl53[i].rangingTest(&measure, false);

  //   Serial.print("VL53[");
  //   Serial.print(i);
  //   Serial.print("] = ");

  //   if (measure.RangeStatus != 4){
  //       Serial.print(measure.RangeMilliMeter);
  //     distances[i] = measure.RangeMilliMeter;
  //   }
      
  //   else{
  //       Serial.print("Out of range");
  //       distances[i] = 0;

  //   }
      
  //   Serial.println(" mm");
  // }

  // // ================= COLOR SENSORS ====================
  // Serial.println("\n==== Color Sensors ====");

  // for (int i = 0; i < 1; i++) {
  //   tcaSelect(i + 1);

  //   uint16_t r, g, b, c;
  //   tcs[i].getRawData(&r, &g, &b, &c);

  //   Serial.print("TCS[");
  //   Serial.print(i);
  //   Serial.println("]:");

  //   Serial.print("  R="); Serial.println(r);
  //   Serial.print("  G="); Serial.println(g);
  //   Serial.print("  B="); Serial.println(b);
  //   Serial.print("  C="); Serial.println(c);

  // int th = 2;
  //   if (r > b && r > g && r >= th){
  //     Serial.println("Color: RED");
  //     digitalWrite(RED, HIGH);
  //     digitalWrite(BLUE, LOW);
  //     digitalWrite(GREEN, LOW);

  //   }else if(b > r && b > g && b >= th){
  //     Serial.println("Color: BLUE");
  //     digitalWrite(RED, LOW);
  //     digitalWrite(BLUE, HIGH);
  //     digitalWrite(GREEN, LOW);

  //   }else if(g > r && g > b && g >= th){
  //     Serial.println("Color: GREEN");
  //     digitalWrite(RED, LOW);
  //     digitalWrite(BLUE, LOW);
  //     digitalWrite(GREEN, HIGH);

  //   }else{
  //     Serial.println("Mixed Color");
  //     digitalWrite(RED, LOW);
  //     digitalWrite(BLUE, LOW);
  //     digitalWrite(GREEN, LOW);
  //   }
  // }

  // Serial.println("---------------------\n");


  // //delay(200);


  // Serial.print("A");
  // Serial.print(distances[0]);
  // Serial.println();
  // if (distances[0] >= 500 || distances[0] <= 50 ) {

  //   moveMotors(i+150, j+150);
  //   i=i+150;
  //   j=j+150;
  // }

  // else {
    
  //   Serial.print("B");
  //   Serial.print(distances[1]);
  //   Serial.println();

  //   if (distances[1] >= 500 || distances[1] <= 50){
  //     moveMotors(i, j+220);
  //     j=j+220;
  //   }
  //   else{
      
  //     Serial.print("C");
  //     Serial.print(distances[2]);
  //     Serial.println();

  //     if (distances[2] >= 500|| distances[2] <= 50 ){
  //       moveMotors(i+220, j);
  //       i=i+220;
  //     }
  //     else{
        
  //         moveMotors(i,j);
        
  //     }

  //   }
    
  // } 



//}

  
  // uint16_t r, g, b, c;
  // float red, green, blue;

  // // Read color data
  // tcs.getRawData(&r, &g, &b, &c);

  // // Avoid divide-by-zero
  // float sum = c;
  // if (sum == 0) sum = 1;

  // // Normalize values (0–255)
  // red = (float)r / sum * 255.0;
  // green = (float)g / sum * 255.0;
  // blue = (float)b / sum * 255.0;

  // Serial.print("R: "); Serial.print((int)red);
  // Serial.print("  G: "); Serial.print((int)green);
  // Serial.print("  B: "); Serial.print((int)blue);
  // Serial.print("  Clear: "); Serial.println(c);

  // // --- Detect basic colors ---
  // if (red > green && red > blue) {
  //     Serial.println("Color: RED");
  // } else if (green > red && green > blue) {
  //     Serial.println("Color: GREEN");
  // } else if (blue > red && blue > green) {
  //     Serial.println("Color: BLUE");
  // } else {
  //     Serial.println("Color: UNKNOWN / MIXED");
  // }

  // Serial.println();
  // delay(500);

 


  // readSensors(distanceA, distanceB, distanceC);

  // Serial.print("A: ");
  // Serial.print(distanceA == 0xFFFF ? 0 : distanceA);
  // Serial.print(" mm  |  B: ");
  // Serial.print(distanceB == 0xFFFF ? 0 : distanceB);
  // Serial.print(" mm  |  C: ");
  // Serial.print(distanceC == 0xFFFF ? 0 : distanceC);
  // Serial.println(" mm");

  // delay(100);







//   // put your main code here, to run repeatedly:

//   readSensors(distanceA, distanceB, distanceC);

//   Serial.print("A");
//   Serial.print(distanceA);
//   Serial.println();
//   if (distanceA >= 500 || distanceA <= 50 ) {

//     moveMotors(i+150, j+150);
//     i=i+150;
//     j=j+150;
//   }

//   else {
    
//     Serial.print("B");
//     Serial.print(distanceB);
//     Serial.println();

//     if (distanceB >= 500 || distanceB <= 50){
//       moveMotors(i, j+220);
//       j=j+220;
//     }
//     else{
      
//       Serial.print("C");
//       Serial.print(distanceC);
//       Serial.println();

//       if (distanceC >= 500|| distanceC <= 50 ){
//         moveMotors(i+220, j);
//         i=i+220;
//       }
//       else{
//         while(1){
//           moveMotors(i,j);
//         }
//       }

//     }
    
//   } 

    
  //Move both motors forward
  // moveMotors(i+600, j+600);  // Move both 800 steps forward
  // i= i+600;
  // j = j+600;
  // delay(1000);

  // moveMotors(i, j+225);
  // j = j+215;
  // delay(1000);

  




  //Move both motors back to 0 position
//   for(int i;i>-1200;i=i-10){
//      moveMotors(i, i);
//     delay(1000);



// for (int pos = 0; pos <= 180; pos++) {
//     myServo.write(pos);
//     delay(10);         // small delay for smooth motion
//   }
//   delay(3000);


//   for (int k = 0;k<4;k++){

//     //Move both motors forward
//     moveMotors(i+600, j+600);  // Move both 800 steps forward
//     i= i+600;
//     j = j+600;
//     delay(1000);

//     moveMotors(i, j+225);
//     j = j+215;
//     delay(1000);
//   }


//   for (int pos = 180; pos >= 0; pos--) {
//     myServo.write(pos);
//     delay(10);
//   }
//   delay(3000);
   

  
  moveMotors(-1200, -1200);
  delay(1000);
  moveMotors(0, 0);
  delay(1000);


  // readSensors(distanceA, distanceB, distanceC);

  // Serial.print("A: ");
  // Serial.print(distanceA == 0xFFFF ? 0 : distanceA);
  // Serial.print(" mm  |  B: ");
  // Serial.print(distanceB == 0xFFFF ? 0 : distanceB);
  // Serial.print(" mm  |  C: ");
  // Serial.print(distanceC == 0xFFFF ? 0 : distanceC);
  // Serial.println(" mm");

  // delay(100);





//   uint16_t r, g, b, c;
//   float red, green, blue;

//   // Read color data
//   tcs.getRawData(&r, &g, &b, &c);

//   // Avoid divide-by-zero
//   float sum = c;
//   if (sum == 0) sum = 1;

//   // Normalize values (0–255)
//   red = (float)r / sum * 255.0;
//   green = (float)g / sum * 255.0;
//   blue = (float)b / sum * 255.0;

//   Serial.print("R: "); Serial.print((int)red);
//   Serial.print("  G: "); Serial.print((int)green);
//   Serial.print("  B: "); Serial.print((int)blue);
//   Serial.print("  Clear: "); Serial.println(c);

//   // --- Detect basic colors ---
//   if (red > green && red > blue) {
//       Serial.println("Color: RED");
//   } else if (green > red && green > blue) {
//       Serial.println("Color: GREEN");
//   } else if (blue > red && blue > green) {
//       Serial.println("Color: BLUE");
//   } else {
//       Serial.println("Color: UNKNOWN / MIXED");
//   }

//   Serial.println();
//   delay(500);









  }
