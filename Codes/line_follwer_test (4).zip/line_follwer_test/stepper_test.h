#ifndef STEPPER_TEST_H
#define STEPPER_TEST_H

#include <Arduino.h>
#include <AccelStepper.h>

// CNC Shield default pin mappings for A4988
#define X_STEP_PIN 2
#define X_DIR_PIN 5
#define Y_STEP_PIN 3
#define Y_DIR_PIN 6
#define ENABLE_PIN 8  // shared enable pin (active LOW)


// Declare global AccelStepper objects
extern AccelStepper stepperx;
extern AccelStepper steppery;

// Function declarations
void initMotors();
void moveMotors(long stepsX, long stepsY);

void setMotorSpeed(float speedX, float speedY);

void stopMotors();

#endif
