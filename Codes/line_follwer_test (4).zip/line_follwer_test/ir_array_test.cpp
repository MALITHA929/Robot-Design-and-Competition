#include "ir_array_test.h"

// Assign pins for 5 sensors (digital pins)
int sensorPins[NUM_SENSORS] = {22, 23, 24, 25,26 ,27, 28, 29};

// Initialize all sensor pins as INPUT
void initSensors() {
  for (int i = 0; i < NUM_SENSORS; i++) {
    pinMode(sensorPins[i], INPUT);
  }
}

// Read all sensors into the provided array
void readSensors(int values[]) {
  for (int i = 0; i < NUM_SENSORS; i++) {
    values[i] = digitalRead(sensorPins[i]);
  }
}

// Print sensor readings for debugging
void printSensorValues(int values[]) {
  Serial.print("Sensors: ");
  for (int i = 0; i < NUM_SENSORS; i++) {
    Serial.print(values[i]);
    Serial.print(" ");
  }
  Serial.println();
}
