#ifndef IR_ARRAY_TEST_H
#define IR_ARRAY_TEST_H

#include <Arduino.h>

// Number of sensors
#define NUM_SENSORS 8

// Function declarations
void initSensors();
void readSensors(int values[]);
void printSensorValues(int values[]);

#endif
