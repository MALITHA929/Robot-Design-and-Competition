#include "TCA_tof.h"

TCA_VL53L0X::TCA_VL53L0X(uint8_t xshutPin, uint8_t newAddress,uint8_t muxChannel, uint8_t muxAddress)
  : _xshutPin(xshutPin),
    _newAddress(newAddress), 
    _muxChannel(muxChannel),
    _muxAddress(muxAddress) {}

// Select mux channel (same for both sensors)
void TCA_VL53L0X::selectMuxChannel() {
  Wire.beginTransmission(_muxAddress);
  Wire.write(1 << _muxChannel);
  Wire.endTransmission();
}

bool TCA_VL53L0X::begin() {

  // Select mux channel first
  selectMuxChannel();

  // Reset the sensor using XSHUT
  pinMode(_xshutPin, OUTPUT);
  digitalWrite(_xshutPin, LOW);
  delay(50);

  // Power on
  digitalWrite(_xshutPin, HIGH);
  delay(50);

  // Initialize at default address 0x29
  if (!_sensor.begin()) {
    Serial.print("VL53 INIT FAILED at sensor ");
    while(1) {
      // Sensor initialisation will fail
    }
    return false;
  }

  // Change I2C address
  _sensor.setAddress(_newAddress);
  delay(10);

  _sensor.startRangeContinuous();

  return true;
}

uint16_t TCA_VL53L0X::readDistance() {
  selectMuxChannel();

  if (_sensor.isRangeComplete()) {
    _lastDistance = _sensor.readRange();
  }

  return _lastDistance;
}
