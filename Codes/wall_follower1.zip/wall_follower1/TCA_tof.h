#ifndef TCA_TOF_H
#define TCA_TOF_H

#include <Arduino.h>
#include <Wire.h>
#include "Adafruit_VL53L0X.h"

class TCA_VL53L0X {
public:
  // Constructor
  TCA_VL53L0X(uint8_t xshutPin, uint8_t newAddress, uint8_t muxChannel, uint8_t muxAddress = 0x70);

  bool begin();
  uint16_t readDistance();
  void selectMuxChannel();

private:
  uint8_t _xshutPin;
  uint8_t _newAddress;
  uint8_t _muxChannel;
  uint8_t _muxAddress;

  Adafruit_VL53L0X _sensor;
  uint16_t _lastDistance = 0;
};

#endif
