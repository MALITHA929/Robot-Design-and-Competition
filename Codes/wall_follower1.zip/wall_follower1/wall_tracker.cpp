#include "wall_tracker.h"

WALLtracker::WALLtracker(
    TCA_VL53L0X* frontSensor,
    TCA_VL53L0X* backSensor,
    PIDController* pidController,
    float targetDistance,
    float k1,
    float k2,
    float baseline
) : _frontSensor(frontSensor),
    _backSensor(backSensor),
    _pid(pidController),
    _targetDistance(targetDistance),
    _k1(k1),
    _k2(k2),
    _baseline(baseline)
{
    dF = dB = 0;
    distanceError = 0;
    angleError = 0;
    combinedVertualMeasurement = 0;
}

// Initialise TOF sensors and PID
void WALLtracker::init() {
    _frontSensor->begin();
    _backSensor->begin();
    _pid->init();
}

uint16_t WALLtracker::getFrontDistance() {
    return dF;
}

uint16_t WALLtracker::getBackDistance() {
    return dB;
}

float WALLtracker::getDistanceError() {
    return distanceError;
}

float WALLtracker::getAngleError() {
    return angleError;
}

float WALLtracker::getCombinedError() {
    return combinedVertualMeasurement;
}

float WALLtracker::computeSteering() {

    // Read sensors
    dF = _frontSensor->readDistance();
    dB = _backSensor->readDistance();

    Serial.print(dF);
    Serial.print(" ");
    Serial.println(dB);

    // Calculate distance error
    float avgDist = (dF + dB) / 2.0;
    distanceError = _targetDistance - avgDist;

    // Calculate angle error
    angleError = atan( (dB - dF) / _baseline );

    // Combine both errors
    combinedVertualMeasurement = -( _k1 * distanceError + _k2 * angleError );

    float setpoint = 0;

    // Update the PID
    float steering = _pid->update(setpoint, combinedVertualMeasurement);  
    return steering;
}
