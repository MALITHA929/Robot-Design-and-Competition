#include <Wire.h>
#include "PID.h"
#include "wall_tracker.h"
#include "stepper_motor.h"
#include "TCA_tof.h"

PIDController pid;
STEPPERcontroller steppers;

// Initialise TOF channels( XSHUT, ADDRESS, CHANNEL)
TCA_VL53L0X toffront(35, 0x30, 0);
TCA_VL53L0X tofback(38, 0x31, 0);

float baseSpeed = 140;      // constant forward speed
float steering;             // pid output
unsigned long lastTime;     // for fixed-time loop

// Wall following attributes
const float targetWalldistance = 60.0;  
const float distance_weight = 0.9;        
const float angle_weight = 0.7;
const float sensor_separation = 80.0;

// Wall follower module
WALLtracker detwall(
  &toffront,
  &tofback,
  &pid,
  targetWalldistance,
  distance_weight,    // k1 = distance weight
  angle_weight,     // k2 = angle weight
  sensor_separation
);

const float LOOP_DT = 0.01; // 10 ms loop = 100 Hz

void setup() {
  // put your setup code here, to run once:
  Serial.begin(115200);

  Wire.begin();

  pinMode(34, OUTPUT);
  pinMode(37,  OUTPUT);

  // Step 1: Turn BOTH sensors OFF
  digitalWrite(34, LOW);
  digitalWrite(37,  LOW);
  delay(40);

  //Initialise the hardware
  steppers.init();
  detwall.init();

  //Configure the PID
  pid.Kp = 50.5f;
  pid.Ki = 0.0f;
  pid.Kd = 0.0f;

  pid.tau = 0.02f;

  pid.limMax =  200;
  pid.limMin = -200;
  pid.limMaxInt = 50;
  pid.limMinInt = -50;

  pid.T  = LOOP_DT;

  pid.init();

  lastTime = millis();
}

void loop() {
  // put your main code here, to run repeatedly:

  // Run PID loop at desired frequency
  if (millis() - lastTime >= LOOP_DT * 1000) {
    lastTime += LOOP_DT * 1000;

    // Get steering correction from wall follower module
    float steering = detwall.computeSteering();

    // Convert to motor speeds
    float left  = baseSpeed - steering;
    float right = baseSpeed + steering;

    // Clamp motor commands
    if (left > 255) left = 255;
    if (left < -255) left = -255;
    if (right > 255) right = 255;
    if (right < -255) right = -255;

    //Run the motors
    steppers.setSpeed(left, right);
    steppers.runMotors();
  }
}


