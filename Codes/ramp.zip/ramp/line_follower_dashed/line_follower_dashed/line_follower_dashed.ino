#include "PID.h"
#include "ir_array.h"
#include "line_tracker.h"
#include "stepper_motor.h"

PIDController pid;
IRarray irsensors;
LINEtracker tracker;
STEPPERcontroller steppers;

float baseSpeed = 200;      // constant forward speed
float steering;             // pid output
unsigned long lastTime;     // for fixed-time loop

const float LOOP_DT = 0.005; 

// Dashed line following
bool lineVisible = true;
unsigned long lastSeenTime = 0;        // last time the line was detected
const unsigned long GAP_TIMEOUT = 2200; // ms allowed for dashed-line gaps / Cahnge according to the dashed line gap
float lastPos = 0.0f;                  // last valid line position

void setup() {
  // put your setup code here, to run once:

  //Initialise the hardware
  irsensors.init();
  steppers.init();
  tracker.init();

  //Configure the PID
  pid.Kp = 55.5f;
  pid.Ki = 0.0f;
  pid.Kd = 0.03f;

  pid.tau = 0.02f;

  pid.limMax =  200;
  pid.limMin = -200;
  pid.limMaxInt = 50;
  pid.limMinInt = -50;

  pid.T  = LOOP_DT;

  pid.init();

  lastTime = millis();
}

void loop() {
  // put your main code here, to run repeatedly:

  // Run PID loop at 10ms
  if (millis() - lastTime >= LOOP_DT * 1000) {
    lastTime += LOOP_DT * 1000;

    // Read IR sensor values
    irsensors.read();

    // Compute the line position
    float pos = tracker.computePosition(irsensors.values);
    
    // If line is found
    if (pos != 999.0f) {
        lineVisible = true;
        lastSeenTime = millis();
        lastPos = pos;
    }
    // If line is not found
    else {
        lineVisible = false;
    }

    // Handle dashed line
    if (!lineVisible && (millis() - lastSeenTime < GAP_TIMEOUT)) {
        // Continue with the previous ir tracks
        pos = lastPos;
    }

    // Handle complete line lost
    if (!lineVisible && (millis() - lastSeenTime >= GAP_TIMEOUT)) {
        // Line lost fallback
        steppers.setSpeed(+100, -100);
        pid.integrator = 0;
        return;
    }

    // Update PID Controller
    float setpoint = 0.0f;
    float error = setpoint - pos;

    steering = pid.update(setpoint, pos);
    
    // Update the motor X, Y speeds
    float right = baseSpeed + steering;
    float left = baseSpeed - steering;

    // Clamp motor commands
    if (left > 255) left = 255;
    if (left < -255) left = -255;
    if (right > 255) right = 255;
    if (right < -255) right = -255;
    
    //Run the motors
    steppers.setSpeed(left, right);
    steppers.runMotors();
  }

}
