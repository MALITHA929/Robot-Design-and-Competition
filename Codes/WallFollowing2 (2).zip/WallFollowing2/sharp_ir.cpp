#include "sharp_ir.h"

void SharpIR::read(){
    int sensorValue;
    float voltage;
    float distance;

    for (int i = 0; i < 2; i++){
      sensorValue = analogRead(IR_PINs[i]);
      voltage = sensorValue * (5.0 / 1023.0);

      float distance = 27.728 * pow(voltage, -1.2045);

      distances[i] = distance;
    }
}


void SharpIR::printValues(){
  for (int i = 0; i < 2; i++){
    Serial.print("Sensor ");
    Serial.print(i + 1);
    Serial.print(": ");
    Serial.print(distances[i]);
    Serial.print("; ");

  }

  Serial.println();
}