#include "sharp_ir.h"
#include "stepper_motor.h"

SharpIR sharpIR;
STEPPERcontroller steppers;

// put your setup code here, to run once:
    float targetDistance = 20.0;   // desired distance to wall (cm)
    float baseline = 16.0;         // distance between sensors (cm)

    // Weight for distance vs angle
    float kDist = 1.0;
    float kAngle = 10.0;

    // PID gains
    float Kp = 0.9;
    float Ki = 0.0;
    float Kd = 0.8;

    // Movement
    float baseSpeed = 150;  
           // forward speed
    unsigned long lastTime;
    // Change PID loop frequency
    const float LOOP_DT = 0.001f;

void setup() {
    Serial.begin(115200);
    steppers.init();
  
}

void loop() {
  // put your main code here, to run repeatedly:
  wallFollow();

}


/////////////////////////////////////////////

float computeWallError(float dF, float dB)
{
    // Distance error (positive = too far from wall)
    float distError = targetDistance - (dF + dB) * 0.5f;

    // Angle error (positive = front farther → rotated outward)
    float angleError = atan2f((dF - dB), baseline);

    // Combined error
    float combined = kDist * distError + kAngle * angleError;

    return combined;
}

float pidUpdate(float error, float dt)
{
    static float prevError = 0;
    static float integral = 0;

    integral += error * dt;
    float derivative = (error - prevError) / dt;
    prevError = error;

    return Kp*error + Ki*integral + Kd*derivative;
}

void computeMotorSpeeds(float steering, float &left, float &right)
{
    left  = baseSpeed + steering;
    right = baseSpeed - steering;

    // clamp
    if(left > 255) left = 255;
    if(left < -255) left = -255;
    if(right > 255) right = 255;
    if(right < -255) right = -255;
}

void wallFollow()
{
    static unsigned long last = 0;
    const float dt = 0.5;   // 20 ms / 50 Hz loop

    if(millis() - lastTime >= LOOP_DT * 1000)
    {   
         lastTime += LOOP_DT * 1000;
        // last = millis();

        sharpIR.read();
        // 1. READ SENSORS
        float dF = sharpIR.distances[0];
        float dB = sharpIR.distances[1];

        // 2. COMBINE INTO ONE ERROR
        float error = computeWallError(dF, dB);

        // 3. PID OUTPUT = STEERING CORRECTION
        float steering = pidUpdate(error, dt);

        // 4. MOTOR SPEEDS
        float left, right;
        computeMotorSpeeds(steering, left, right);

        // 5. RUN MOTORS
        steppers.setSpeed(left, right);
        steppers.runMotors();
    }
}


