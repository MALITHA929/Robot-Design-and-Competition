#include "stepper_motor.h"

// Constructor initializes stepper objects
STEPPERcontroller::STEPPERcontroller()
: _stepperRM(AccelStepper::DRIVER, RM_STEP_PIN, RM_DIR_PIN),
  _stepperLM(AccelStepper::DRIVER, LM_STEP_PIN, LM_DIR_PIN)
{
}

void STEPPERcontroller::init() {
    // Enable drivers
    pinMode(ENABLE_PIN, OUTPUT);
    digitalWrite(ENABLE_PIN, LOW);   

    // Set default parameters
    _stepperRM.setMaxSpeed(1000);
    _stepperLM.setMaxSpeed(1000);

    // Setting the acceleration
    _stepperRM.setAcceleration(50);   
    _stepperLM.setAcceleration(50);

    _stepperRM.setSpeed(0);
    _stepperLM.setSpeed(0);
}

void STEPPERcontroller::setSpeed(float speedRM, float speedLM) {
    _stepperRM.setSpeed(speedRM);
    _stepperLM.setSpeed(-speedLM);
}

void STEPPERcontroller::runMotors() {
    // Non-blocking continuous stepping
    _stepperRM.runSpeed();
    _stepperLM.runSpeed();
}

void STEPPERcontroller::runSteps(long stepsRM, long stepsLM) {
  // Run motors to the desired position using acceleration and deceleration
  _stepperRM.moveTo(stepsRM);
  _stepperLM.moveTo(stepsLM);

  //Run the motors until finished
  while (_stepperLM.distanceToGo() != 0 || _stepperRM.distanceToGo() != 0) {
    _stepperRM.run();
    _stepperLM.run();
  }
}

void STEPPERcontroller::turnRight90() {
  // Stop the motors initially
  _stepperRM.setSpeed(0);
  _stepperLM.setSpeed(0);

  long lm_steps = S2_STEPS_FOR_90_TURN;
  long rm_steps = S1_STEPS_FOR_90_TURN;

  _stepperRM.setCurrentPosition(0);
  _stepperLM.setCurrentPosition(0);
   
  // Set the steps
  _stepperRM.moveTo(lm_steps);
  _stepperLM.moveTo(rm_steps);
  
  while (_stepperRM.isRunning() || _stepperLM.isRunning()) {
      _stepperRM.run();
      _stepperLM.run();
  }  
}

void STEPPERcontroller::turnLeft90() {
  // Stop the motors initially
  _stepperRM.setSpeed(0);
  _stepperLM.setSpeed(0);

  long lm_steps = S2_STEPS_FOR_90_TURN;
  long rm_steps = S1_STEPS_FOR_90_TURN;

  _stepperRM.setCurrentPosition(0);
  _stepperLM.setCurrentPosition(0);
  
  // Set the steps
  _stepperRM.moveTo(rm_steps);
  _stepperLM.moveTo(-lm_steps);

  while (_stepperRM.isRunning() || _stepperLM.isRunning()) {
      _stepperRM.run();
      _stepperLM.run();
  }  
}

void STEPPERcontroller::stop() {
    _stepperRM.setSpeed(0);
    _stepperLM.setSpeed(0);
}
