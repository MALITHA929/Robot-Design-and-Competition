#include "PID.h"
#include "ir_array.h"
#include "line_tracker.h"
#include "stepper_motor.h"
#include "tof_manager.h"
#include "line_follower.h"

// GRID
bool grid[8][9];

// Starting grid position
int row = 0;
int col = 0;

enum Direction { NORTH, EAST, SOUTH, WEST };

// Starting Direction
Direction heading = EAST;

// Avoid junction debounce
bool previouslyAtjunction = false;

// Avoid turning debounce
bool previouslyTurntaken;

// TOF pins
uint8_t xshutPins[6] = {33, 34, 35, 36, 37, 38};
const uint8_t interruptPin = 19;

PIDController pid;
IRarray irsensors;
LINEtracker tracker;
STEPPERcontroller steppers;
LineFollower linefollower;

TOF_Manager tof(xshutPins, interruptPin);

float baseSpeed = 200;      // constant forward speed
float steering;             // pid output
unsigned long lastTime;     // for fixed-time loop

const float LOOP_DT = 0.005; // 10 ms loop = 100 Hz

void setup() {
  // put your setup code here, to run once:
  Serial.begin(115200);

  //Initialise the hardware
  irsensors.init();
  steppers.init();
  tracker.init();
  linefollower.init();
  
  // Initialise TOFs
  if (!tof.initAllSensors()) {
      Serial.println("TOF init failed!");
      while (1);
  }
  
  // Inturrupt sensor, LOW threshold, HIGH threshold
  tof.startInterruptSensor(3, 200, 0);

  //Wire.begin();

  //Configure the PID
  pid.Kp = 55.5f;
  pid.Ki = 0.0f;
  pid.Kd = 0.0f;

  pid.tau = 0.02f;

  pid.limMax =  200;
  pid.limMin = -200;
  pid.limMaxInt = 50;
  pid.limMinInt = -50;

  pid.T  = LOOP_DT;

  pid.init();

  lastTime = millis();
}

void loop() {
  // put your main code here, to run repeatedly:

  // Run PID loop at 10ms
  if (millis() - lastTime >= LOOP_DT * 1000) {
    lastTime += LOOP_DT * 1000;

    // Read IR sensor values
    irsensors.read();

    // Compute the line position
    float pos = tracker.computePosition(irsensors.values);
    
    // Handle line lost( Optional )
    if (pos == 999.0f) {
        // Lost line behavior – slow turn in last known direction
        steppers.setSpeed(+100, -100);
        pid.integrator = 0;      // optional: prevent windup
        return;
    }

    // Update PID Controller
    float setpoint = 0.0f;
    float error = setpoint - pos;

    steering = pid.update(setpoint, pos);
    
    // Update the motor X, Y speeds
    float right = baseSpeed + steering;
    float left = baseSpeed - steering;

    // Clamp motor commands
    if (left > 255) left = 255;
    if (left < -255) left = -255;
    if (right > 255) right = 255;
    if (right < -255) right = -255;
    
    //Run the motors
    steppers.setSpeed(left, right);
    steppers.runMotors();

    // Check junctions
    bool isJunction = tracker.detectJunction(irsensors.values);
    //Serial.println(isJunction);

    if (isJunction && !previouslyAtjunction) {
      // Update the grid positions
      updateGridPosition();    
      
      previouslyAtjunction = true;
      previouslyTurntaken = false;
    }

    if (!isJunction) {
      // Avoid bouncing on same junction
      previouslyAtjunction = false;  
    }

    if (( col == 8 ) && ( row % 2 == 0 ) && !previouslyTurntaken) {
      // Heading NORTH at right-hand side
      heading = NORTH;
      
      // Execute left turn
      steppers.turnLeft90();

      previouslyTurntaken = true;

      // Resync with the PID loop
      lastTime = millis();      
      return;
    }

    if (( col == 8 ) && ( row % 2 == 1 ) && !previouslyTurntaken) {
      // Heading WEST at right-hand side
      heading = WEST;

      // Execute left turn
      steppers.turnLeft90();

      previouslyTurntaken = true;

      // Resync with the PID loop
      lastTime = millis();      
      return;
    }

    if (( col == 0 ) && ( row % 2 == 1 ) && !previouslyTurntaken) {
      // Heading NORTH at left-hand side
      heading = NORTH;

      // Execute right turn
      steppers.turnRight90();

      previouslyTurntaken = true;

      // Resync with the PID loop
      lastTime = millis();      
      return;
    }

    if (( col == 0 ) && ( row % 2 == 0 ) && ( row != 0 ) && !previouslyTurntaken) {
      // Heading EAST at left-hand side
      heading = EAST;

      // Execute left turn
      steppers.turnRight90();

      previouslyTurntaken = true;

      // Resync with the PID loop
      lastTime = millis();      
      return;
    }

    if (( col == 0 ) && (row == 7 ) && !previouslyTurntaken) {
       // Stop all motors
      steppers.setSpeed(0, 0);

      // Disable PID or other actions
      pid.integrator = 0;

      // Prevent further code from running
      while (true) {
          // do nothing, stop the robot
      }
    }

    if (tof.tofObstacleTriggered()) {   
      // Clear the interrupt
      tof.clearInterrupt();

      // Return to the previously crossed junction
      while(!tracker.detectJunction(irsensors.values)) {
        linefollower.update(false);
      }
      
      // Handle object detection
      if (heading == EAST) {
        steppers.turnLeft90();
        lastTime = millis();

        while(!tracker.detectJunction(irsensors.values)) {
          linefollower.update(true);
        } 

        steppers.turnRight90();
        lastTime = millis();

        while(tracker.detectJunction(irsensors.values)) {
          linefollower.update(true);
        }

        for (int i = 0; i < 11; i++) {
          steppers.runMotors();
          delay(5);
        }
        lastTime = millis();

        while(tracker.detectJunction(irsensors.values)) {
          linefollower.update(true);
        }

        steppers.turnRight90();
        lastTime = millis();

        while(!tracker.detectJunction(irsensors.values)) {
          linefollower.update(true);
        }

        steppers.turnLeft90();
        
        //Update grid positions
        col += 2;
      }

      if (heading == WEST) {
        steppers.turnRight90();
        lastTime = millis();

        while(!tracker.detectJunction(irsensors.values)) {
          linefollower.update(true);
        } 

        steppers.turnLeft90();
        lastTime = millis();

        while(tracker.detectJunction(irsensors.values)) {
          linefollower.update(true);
        }

        for (int i = 0; i < 11; i++) {
          steppers.runMotors();
          delay(5);
        }
        lastTime = millis();

        while(tracker.detectJunction(irsensors.values)) {
          linefollower.update(true);
        }

        steppers.turnLeft90();
        lastTime = millis();

        while(!tracker.detectJunction(irsensors.values)) {
          linefollower.update(true);
        }

        steppers.turnRight90();
        
        //Update grid positions
        col -= 2;
      }

      lastTime = millis();
      return;
    }

  }
}

void updateGridPosition() {
  // Update the grid positions
  switch (heading) {
    case NORTH: row++; break;
    case SOUTH: row--; break;
    case EAST:  col++; break;
    case WEST:  col--; break;
  }

}
