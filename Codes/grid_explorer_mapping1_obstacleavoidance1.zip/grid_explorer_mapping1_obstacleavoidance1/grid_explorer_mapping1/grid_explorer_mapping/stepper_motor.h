#ifndef STEPPER_MOTOR_H
#define STEPPER_MOTOR_H

#include <Arduino.h>
#include <AccelStepper.h>

// CNC Shield default A4988 pin mappings
#define RM_STEP_PIN 2
#define RM_DIR_PIN 5
#define LM_STEP_PIN 3
#define LM_DIR_PIN 6
#define ENABLE_PIN 8  

#define S1_STEPS_FOR_90_TURN 0
#define S2_STEPS_FOR_90_TURN 255

class STEPPERcontroller {
public:
    // Constructor
    STEPPERcontroller();

    void init();                          
    void setSpeed(float speedRM, float speedLM);

    // Move motors 1-step in setSpeed
    void runMotors();

    // Move motors to a desired position ( Optional| Not needed for PID control )
    void runSteps(long stepsRM, long stepsLM);
    
    // Turn right 90 degrees
    void turnRight90();
    
    // Turn left 90 degrees
    void turnLeft90();

    // Stop both motors
    void stop();                             

private:
    AccelStepper _stepperRM;
    AccelStepper _stepperLM;
};

#endif
