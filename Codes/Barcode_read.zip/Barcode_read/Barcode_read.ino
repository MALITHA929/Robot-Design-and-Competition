#include <Arduino.h>
#include "barcode.h"
#include "stepper_motor.h"


BARCODEreader barcode;
STEPPERcontroller stepperCtrl;


void setup() {
  Serial.begin(9600);
  barcode.init();

  // Initialize motors
  stepperCtrl.init();

    // Start motors with a base forward speed
  float baseSpeed = 50;   // adjust for your setup
  stepperCtrl.setSpeed(baseSpeed, baseSpeed);
  
  Serial.println("Barcode reader ready. Move sensor across barcode lines...");
  bool currentState = 0;
  // Wait until middle sensor sees white


  while (!barcode.isOnWhite()) {
    stepperCtrl.runMotors();
    delay(10);  // poll every 10 ms
  }

}

void loop() {
  
    // Keep motors running continuously
  stepperCtrl.runMotors();

  // Continuously update barcode reader
  barcode.update();

  // If reached 10 transitions, finish
  if (barcode.isComplete()) {

    stepperCtrl.stop();

    barcode.decodeBarcode();


    Serial.println("Barcode value: ");

    Serial.println(barcode.barcode_Val());

    // Halt here so results stay visible
    while (true) {
      delay(1000);
    }
  }

  delay(5); // small delay to avoid flooding
}