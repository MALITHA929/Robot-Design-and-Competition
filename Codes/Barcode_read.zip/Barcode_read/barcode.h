#ifndef BARCODE_READER_H
#define BARCODE_READER_H

#include <Arduino.h>
#include "ir_array.h"

class BARCODEreader {
public:
    // Constructor
    BARCODEreader();

    // Initialize reader
    void init();

    // Call this repeatedly in loop to detect transitions and record timing
    void update();

    // Returns true when barcode reading is complete
    bool isComplete();

    // Print raw timing data
    void printTimings();

    // Convert timings to binary barcode
    void decodeBarcode();

    // Print decoded binary barcode
    void printBarcode();

    bool isOnWhite();   // check if corner sensor sees white

    int barcode_Val();
    // Expose count for debugging
    int getCount();
  
private:
    IRarray* ir;  // Pointer to IRarray object

    static const int MAX_TRANSITIONS = 10;   // Fixed limit of 10 transitions
    unsigned long timestamps[MAX_TRANSITIONS]; 
    unsigned long new_timestamps[MAX_TRANSITIONS/2]; // Time intervals between transitions
    bool barcodeBits[MAX_TRANSITIONS/2];          // Decoded binary barcode
    int count;                                  // Number of recorded transitions

    bool lastState;                             // Previous sensor state
    unsigned long lastTime;                     // Time of last transition
    int newCount;

    bool complete;                              // Flag to indicate barcode read is done

    // Helper: detect transition (e.g., black to white)
    bool detectTransition(bool currentState);
};

#endif