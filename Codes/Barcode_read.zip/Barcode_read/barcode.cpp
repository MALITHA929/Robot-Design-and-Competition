#include "barcode.h"

BARCODEreader::BARCODEreader()
: ir(nullptr), count(0), lastState(false), lastTime(0), complete(false)
{
    for (int i = 0; i < MAX_TRANSITIONS; i++) {
        timestamps[i] = 0;
        barcodeBits[i] = false;
    }
}

void BARCODEreader::init() {
    ir = new IRarray();   // Create IRarray instance
    ir->init();           // Initialize sensor pins
    lastTime = millis();  // Initialize timing
    lastState = false;    // Assume starting on black
    count = 0;
    complete = false;
}

bool BARCODEreader::isOnWhite() {
    ir->read();
    return ir->values[4];   // corner
}

bool BARCODEreader::detectTransition(bool currentState) {
    return currentState != lastState;
}

void BARCODEreader::update() {
    if (complete || count >= MAX_TRANSITIONS) return;

    ir->read();
    bool currentState = ir->values[4];  // Use corner sensor

    if (detectTransition(currentState)) {
        unsigned long now = millis();
        unsigned long duration = now - lastTime;

        if(lastState){
            timestamps[count] = duration;
        }
        lastTime = now;
        lastState = currentState;
        count++;
        
        if (count >= MAX_TRANSITIONS) {
            complete = true;
        }
    }
}

bool BARCODEreader::isComplete() {
    return complete;
}



// This convert the timestamp array to bit array.

void BARCODEreader::decodeBarcode() {
    if (!complete) return;
    //keep only odd-indexed timestamps (1, 3, 5, ...)
    newCount = 0;

    for (int i = 1; i < count; i += 2) {
        new_timestamps[newCount] = timestamps[i];
        newCount++;
    }

    // Compute average duration of new timestamps
    unsigned long sum = 0;
    for (int i = 0; i < newCount; i++) {
        sum += new_timestamps[i];
    }
    unsigned long avg = (newCount > 0) ? (sum / newCount) : 0;

    // Threshold: longer than average → 1, shorter → 0
    for (int i = 0; i < newCount; i++) {
        barcodeBits[newCount - i - 1] = (new_timestamps[i] > avg);
    }

    return barcodeBits;
}



//Calculate the barcode value.

int BARCODEreader::barcode_Val() {
    int sum = 0;
    // Loop backwards through the filtered bits
    for (int i = newCount - 1; i >= 0; i--) {
        sum = (sum << 1) | (barcodeBits[i] ? 1 : 0);
    }
    return sum;
}


int BARCODEreader::getCount() {
    return count;
}


/*

//  For debugging purposes

void BARCODEreader::printTimings() {
    Serial.println("Raw timing data:");
    for (int i = 0; i < count; i++) {
        Serial.print(timestamps[i]);
        Serial.print(" ");
    }
    Serial.println();
}

//For printing purpose
void BARCODEreader::printBarcode() {
    Serial.println("Decoded barcode:");
    for (int i = 0; i < newCount; i++) {
        Serial.print(barcodeBits[i] ? "1" : "0");
    }
    Serial.println();

    Serial.println("Decoded barcode (reversed):");
    for (int i = newCount - 1; i >= 0; i--) {
        Serial.print(barcodeBits[i] ? "1" : "0");
    }
    Serial.println();

}
*/
