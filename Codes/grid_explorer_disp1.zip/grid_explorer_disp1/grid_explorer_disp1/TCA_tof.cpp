#include "TCA_tof.h"

TCA_VL53L0X::TCA_VL53L0X(uint8_t channel, uint8_t muxAddress)
  : _channel(channel), _muxAddress(muxAddress) {}

// Select the correct channel on TCA9548A
void TCA_VL53L0X::selectChannel() {
  Wire.beginTransmission(_muxAddress);

  // Enable the channel
  Wire.write(1 << _channel);  
  Wire.endTransmission();
}

// Initialize VL53L0X on selected mux channel
bool TCA_VL53L0X::begin() {
  selectChannel();

  if (!_sensor.begin()) {
    return false;
  }

  // Start continuous ranging mode on each sensor 
  _sensor.startRangeContinuous();
  return true;
}

// Read the distance (mm)
uint16_t TCA_VL53L0X::readDistance() {
  selectChannel();

  if (_sensor.isRangeComplete()) {
    _lastDistance =  _sensor.readRange();
  }
  
  // Always return a distance reading
  return _lastDistance; 
}
