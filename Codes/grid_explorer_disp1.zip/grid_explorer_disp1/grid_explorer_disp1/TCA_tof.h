#ifndef TCA_TOF_H
#define TCA_TOF_H

#include <Arduino.h>
#include <Wire.h>
#include "Adafruit_VL53L0X.h"

class TCA_VL53L0X {
public:
  // Constructor
  TCA_VL53L0X(uint8_t channel, uint8_t muxAddress = 0x70);

  bool begin();
  uint16_t readDistance();
  void selectChannel();

private:
  uint8_t _channel;
  uint8_t _muxAddress;
  Adafruit_VL53L0X _sensor;
  uint16_t _lastDistance = 0;
};

#endif
