#ifndef OLED_DISPLAY_H
#define OLED_DISPLAY_H

#include <Arduino.h>
#include <Wire.h>
#include <Adafruit_GFX.h>
#include <Adafruit_SH110X.h>

class OLED_Display {
public:
    OLED_Display(uint8_t oledAddress = 0x3C,
                 uint8_t muxAddress = 0x70,
                 uint8_t muxChannel = 1,
                 uint8_t width = 128,
                 uint8_t height = 64);

    void begin();
    void clear();

    // Standard Display Functions (clear → print → show)
    void displayText(const String &text, int x = 0, int y = 0, uint8_t size = 1);
    void displayCentered(const String &text, uint8_t size = 1);
    void displayNumber(long num, int x = 0, int y = 0, uint8_t size = 1);
    void displayNumberCentered(long num, uint8_t size = 1);   // NEW FUNCTION

    // Multi-print mode (no auto-clear)
    void startWrite();
    void writeText(const String &text, int x, int y, uint8_t size = 1);
    void writeNumber(long num, int x, int y, uint8_t size = 1);
    void finishWrite();

private:
    void selectMuxChannel();

    uint8_t _oledAddr;
    uint8_t _muxAddr;
    uint8_t _muxChannel;
    uint8_t _width;
    uint8_t _height;

    Adafruit_SH1106G *_oled;
};

#endif
