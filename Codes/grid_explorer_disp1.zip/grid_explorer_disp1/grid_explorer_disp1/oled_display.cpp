#include "OLED_Display.h"

// Constructor
OLED_Display::OLED_Display(uint8_t oledAddress,
                           uint8_t muxAddress,
                           uint8_t muxChannel,
                           uint8_t width,
                           uint8_t height)
{
    _oledAddr = oledAddress;
    _muxAddr = muxAddress;
    _muxChannel = muxChannel;
    _width = width;
    _height = height;

    _oled = new Adafruit_SH1106G(_width, _height, &Wire, -1);
}

// Select multiplexer channel
void OLED_Display::selectMuxChannel() {
    Wire.beginTransmission(_muxAddr);
    Wire.write(1 << _muxChannel);
    Wire.endTransmission();
}

// Initialize OLED
void OLED_Display::begin() {
    selectMuxChannel();
    _oled->begin(_oledAddr, true);
    _oled->clearDisplay();
    _oled->display();
}

void OLED_Display::clear() {
    selectMuxChannel();
    _oled->clearDisplay();
    _oled->display();
}

// AUTO-CLEAR FUNCTIONS
void OLED_Display::displayText(const String &text, int x, int y, uint8_t size) {
    selectMuxChannel();
    _oled->clearDisplay();
    _oled->setTextSize(size);
    _oled->setTextColor(SH110X_WHITE);
    _oled->setCursor(x, y);
    _oled->print(text);
    _oled->display();
}

void OLED_Display::displayCentered(const String &text, uint8_t size) {
    selectMuxChannel();
    _oled->clearDisplay();
    _oled->setTextSize(size);
    _oled->setTextColor(SH110X_WHITE);

    int16_t x1, y1;
    uint16_t w, h;
    _oled->getTextBounds(text, 0, 0, &x1, &y1, &w, &h);

    int x = (_width - w) / 2;
    int y = (_height - h) / 2;

    _oled->setCursor(x, y);
    _oled->print(text);
    _oled->display();
}

void OLED_Display::displayNumber(long num, int x, int y, uint8_t size) {
    selectMuxChannel();
    _oled->clearDisplay();
    _oled->setTextSize(size);
    _oled->setTextColor(SH110X_WHITE);
    _oled->setCursor(x, y);
    _oled->print(num);
    _oled->display();
}

void OLED_Display::displayNumberCentered(long num, uint8_t size) {
    selectMuxChannel();
    _oled->clearDisplay();
    _oled->setTextSize(size);
    _oled->setTextColor(SH110X_WHITE);

    String txt = String(num);

    int16_t x1, y1;
    uint16_t w, h;
    _oled->getTextBounds(txt, 0, 0, &x1, &y1, &w, &h);

    int x = (_width - w) / 2;
    int y = (_height - h) / 2;

    _oled->setCursor(x, y);
    _oled->print(txt);
    _oled->display();
}

// MULTIPLE PRINTING MODE (NO CLEARING)
// Call startWrite at the begining
void OLED_Display::startWrite() {
    selectMuxChannel();
    _oled->clearDisplay();
}

void OLED_Display::writeText(const String &text, int x, int y, uint8_t size) {
    selectMuxChannel();
    _oled->setTextSize(size);
    _oled->setTextColor(SH110X_WHITE);
    _oled->setCursor(x, y);
    _oled->print(text);
}

void OLED_Display::writeNumber(long num, int x, int y, uint8_t size) {
    selectMuxChannel();
    _oled->setTextSize(size);
    _oled->setTextColor(SH110X_WHITE);
    _oled->setCursor(x, y);
    _oled->print(num);
}

void OLED_Display::finishWrite() {
    selectMuxChannel();
    _oled->display();
}
