#include "PID.h"
#include "ir_array.h"
#include "line_tracker.h"
#include "stepper_motor.h"
#include "TCA_tof.h"
#include "oled_display.h"

// GRID
bool grid[8][9];

// Starting grid position
int row = 0;
int col = 0;

enum Direction { NORTH, EAST, SOUTH, WEST };

// Starting Direction
Direction heading = EAST;

// Avoid junction debounce
bool previouslyAtjunction = false;

// Avoid turning debounce
bool previouslyTurntaken;

PIDController pid;
IRarray irsensors;
LINEtracker tracker;
STEPPERcontroller steppers;

// OLED Display
OLED_Display oled(0x3C, 0x70, 1, 128, 64);
// parameters: oledAddress, muxAddress, muxChannel, width, height

//TCA_VL53L0X toffront(0);

float baseSpeed = 200;      // constant forward speed
float steering;             // pid output
unsigned long lastTime;     // for fixed-time loop

const float LOOP_DT = 0.005; // 10 ms loop = 100 Hz

void setup() {
  // put your setup code here, to run once:
  Serial.begin(115200);

  //Initialise the hardware
  irsensors.init();
  steppers.init();
  tracker.init();

  Wire.begin();
  oled.begin();
  delay(20);

  oled.displayCentered("ROBOT: Begin Count");
  delay(1000);

  //toffront.begin();

  //Configure the PID
  pid.Kp = 55.5f;
  pid.Ki = 0.0f;
  pid.Kd = 0.0f;

  pid.tau = 0.02f;

  pid.limMax =  200;
  pid.limMin = -200;
  pid.limMaxInt = 50;
  pid.limMinInt = -50;

  pid.T  = LOOP_DT;

  pid.init();

  lastTime = millis();
}

void loop() {
  // put your main code here, to run repeatedly:

  // Run PID loop at 10ms
  if (millis() - lastTime >= LOOP_DT * 1000) {
    lastTime += LOOP_DT * 1000;

    // Read IR sensor values
    irsensors.read();

    // Compute the line position
    float pos = tracker.computePosition(irsensors.values);
    
    // Handle line lost( Optional )
    if (pos == 999.0f) {
        // Lost line behavior – slow turn in last known direction
        steppers.setSpeed(+100, -100);
        pid.integrator = 0;      // optional: prevent windup
        return;
    }

    // Update PID Controller
    float setpoint = 0.0f;
    float error = setpoint - pos;

    steering = pid.update(setpoint, pos);
    
    // Update the motor X, Y speeds
    float right = baseSpeed + steering;
    float left = baseSpeed - steering;

    // Clamp motor commands
    if (left > 255) left = 255;
    if (left < -255) left = -255;
    if (right > 255) right = 255;
    if (right < -255) right = -255;
    
    //Run the motors
    steppers.setSpeed(left, right);
    steppers.runMotors();

    // Check junctions
    bool isJunction = tracker.detectJunction(irsensors.values);
    //Serial.println(isJunction);

    if (isJunction && !previouslyAtjunction) {
      // Update the grid positions
      updateGridPosition();   

      // Value, x-pos, y-pos, size
      oled.startWrite();  
      oled.writeText("X:", 0, 50, 1);
      oled.writeNumber(col, 35, 50, 1);
      oled.writeText("Y:", 0, 30, 1);
      oled.writeNumber(row, 35, 30, 1);
      oled.writeText("DIR:", 0, 10, 1);
      oled.writeText(directionToString(heading), 35, 10, 1);
      oled.finishWrite(); 
      
      previouslyAtjunction = true;
      previouslyTurntaken = false;
    }

    if (!isJunction) {
      // Avoid bouncing on same junction
      previouslyAtjunction = false;  
    }

    if (( col == 8 ) && ( row % 2 == 0 ) && !previouslyTurntaken) {
      // Heading NORTH at right-hand side
      heading = NORTH;
      
      // Execute left turn
      steppers.turnLeft90();

      previouslyTurntaken = true;

      // Resync with the PID loop
      lastTime = millis();      
      return;
    }

    if (( col == 8 ) && ( row % 2 == 1 ) && !previouslyTurntaken) {
      // Heading WEST at right-hand side
      heading = WEST;

      // Execute left turn
      steppers.turnLeft90();

      previouslyTurntaken = true;

      // Resync with the PID loop
      lastTime = millis();      
      return;
    }

    if (( col == 0 ) && ( row % 2 == 1 ) && !previouslyTurntaken) {
      // Heading NORTH at left-hand side
      heading = NORTH;

      // Execute right turn
      steppers.turnRight90();

      previouslyTurntaken = true;

      // Resync with the PID loop
      lastTime = millis();      
      return;
    }

    if (( col == 0 ) && ( row % 2 == 0 ) && ( row != 0 ) && !previouslyTurntaken) {
      // Heading EAST at left-hand side
      heading = EAST;

      // Execute left turn
      steppers.turnRight90();

      previouslyTurntaken = true;

      // Resync with the PID loop
      lastTime = millis();      
      return;
    }

    if (( col == 0 ) && (row == 7 )) {
       // Stop all motors
      steppers.setSpeed(0, 0);

      // Disable PID or other actions
      pid.integrator = 0;

      // Prevent further code from running
      while (true) {
          // do nothing, stop the robot
      }
    }

  }
}

void updateGridPosition() {
  // Update the grid positions
  switch (heading) {
    case NORTH: row++; break;
    case SOUTH: row--; break;
    case EAST:  col++; break;
    case WEST:  col--; break;
  }

}

// Convert heading values to strings
String directionToString(Direction d) {
    switch (d) {
        case NORTH: return "NORTH";
        case EAST:  return "EAST";
        case SOUTH: return "SOUTH";
        case WEST:  return "WEST";
        default:    return "UNKNOWN";
    }
}
