#include "stepper_motor.h"
#include "sharp_ir.h"


// const int IR_PIN = A0;   // Analog pin connected to sensor
const int baseSpeed = 100;
float maxDist = 15.0f;
float minDist = 13.0f;
const int _stepsFor90DegreeTurn = 260;

int sensor = 0;
int tm_count = 0;

float distance;

STEPPERcontroller _steppers;
SharpIR sharpIR;

void setup() {
  Serial.begin(9600);
  _steppers.init();

  sharpIR.read();
  distance = sharpIR.distances[sensor]; 
}

void loop() {

  ///////////////////////////////////////////////////

  // for (int i=0;i<10;i++){
  //     _steppers.turn(25, 50, 150);
  //     _steppers.turn(175, 70, 150);

  // }



  if ((distance > 30.0)&& (tm_count = 0)){

     tm_count = tm_count +1;
    _steppers.runForward(baseSpeed, 300);
    _steppers.turn(-baseSpeed, baseSpeed, _stepsFor90DegreeTurn);  /// Turn left
    _steppers.runForward(baseSpeed, 600);
    _steppers.turn(-baseSpeed, baseSpeed, ((_stepsFor90DegreeTurn / 2)+40));  /// Turn left
    _steppers.runForward(baseSpeed, 300);

    //  _steppers.turn(-baseSpeed, baseSpeed, 80);  /// Turn left
    //  _steppers.runForward(baseSpeed, 800);

  //    ///////////////////////////////////////////////////
  //    for (int i=0;i<10;i++){
  //     _steppers.turn(145, 50, 200);
  //     _steppers.turn(115, 70, 40);
  //    // _steppers.runForward(100, 20);

  //    }
     
  //     //////////////////////////////////////



     if (sensor == 1) {
      sensor = 0;
      maxDist = 15.0f;
      minDist = 13.0f;

     }else{
     
      sensor = 1;
      maxDist = 20.0f;
      minDist = 15.0f;
     }

     
  }

  circularWallFollow();
}

void circularWallFollow(){
      // Convert voltage to distance using empirical formula
      // Works approximately for GP2Y0A21YK0F (10–80 cm)
      sharpIR.read();
      distance = sharpIR.distances[sensor]; 

      // Serial.println(distance);
    
      if (distance >= minDist && distance <= maxDist){
        //_steppers.turn(baseSpeed, baseSpeed, 25);
        _steppers.setSpeed(baseSpeed, baseSpeed);
        _steppers.runMotors();

      }else if (distance > maxDist){
        //_steppers.turn(baseSpeed - 30, baseSpeed + 30, 50);}
        _steppers.setSpeed(baseSpeed - 30, baseSpeed + 30);
        _steppers.runMotors();

      }else if (distance < minDist){
      //   _steppers.turn(baseSpeed + 30, baseSpeed - 30, 50);
        _steppers.setSpeed(baseSpeed + 50, baseSpeed - 50);
        _steppers.runMotors();

      }

      delay(5);
}